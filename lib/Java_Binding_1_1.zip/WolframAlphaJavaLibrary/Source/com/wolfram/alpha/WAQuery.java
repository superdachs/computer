/*
 * Created on Nov 8, 2009
 *
 */
package com.wolfram.alpha;


public interface WAQuery extends WAQueryParameters {

    WAQuery copy();
    
}
