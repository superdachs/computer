/*
 * Created on Dec 9, 2009
 *
 */
package com.wolfram.alpha;


public interface WAPlainText {

    String getText();
    
}
